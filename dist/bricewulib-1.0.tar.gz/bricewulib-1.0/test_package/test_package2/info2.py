class Info2():
    def __init__(self):
        pass

    @staticmethod
    def print_hello2():
        print('hello this is Info2')