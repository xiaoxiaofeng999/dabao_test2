from distutils.core import setup

setup(
    name= 'bricewulib',
    version='1.0',
    author_email='xiaoxiaofeng1119@163.com',
    url='https://mp.csdn.net/',
    description= 'this is a test lib',
    packages = ['test_package','test_package.test_package2']
)
