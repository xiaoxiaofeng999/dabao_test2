class Info1:
    def __init__(self):
        pass
    @staticmethod
    def print_hello():
        print('hello the world.')